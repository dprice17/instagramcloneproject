const posts = [
    {
        name: "Vincent van Gogh",
        username: "vincey1853",
        location: "Zundert, Netherlands",
        avatar: "images/avatar-vangogh.jpg",
        post: "images/post-vangogh.jpg",
        comment: "just took a few mushrooms lol",
        likes: 21
    },
    {
        name: "Gustave Courbet",
        username: "gus1819",
        location: "Ornans, France",
        avatar: "images/avatar-courbet.jpg",
        post: "images/post-courbet.jpg",
        comment: "i'm feelin a bit stressed tbh",
        likes: 4
    },
        {
        name: "Joseph Ducreux",
        username: "jd1735",
        location: "Paris, France",
        avatar: "images/avatar-ducreux.jpg",
        post: "images/post-ducreux.jpg",
        comment: "gm friends! which coin are YOU stacking up today?? post below and WAGMI!",
        likes: 152
    }
]

const containerEl = document.getElementById("container")

function renderPosts(){
    
for (let i = 0; i < posts.length; i++){
    
      containerEl.innerHTML += 
        `
        <section>
        
                <div class="container">
                    
                    <div class="post-information">
                        <a href="#"><img class="post-avatar-img" src="${posts[i].avatar}" alt="profile picture of oldgram user"></a>
                        <p class="post-data">
                        <a href=""><span class="post-name">${posts[i].name}</span></a>
                        <br>${posts[i].location}
                        </p> 
                        <div class="circlebase post-dot"></div>
                        <div class="circlebase post-dot"></div>
                        <div class="circlebase post-dot"></div>
                    </div>
                    
                    <a href="#"><img class="post-img" src="${posts[i].post}"></a>
                    <div class="icons">
                        <img src="images/icon-heart.png" alt="image oldgram of like button" class="icons-img">
                        <img src="images/icon-comment.png" alt="image of oldgram comment button" class="icons-img">
                        <img src="images/icon-dm.png" alt="image of oldgram direct message button" class="icons-img">
                    </div>
                    
                    <p class="post-likes">${posts[i].likes} likes</p>
                    
                    <div class="comments-section">
                        <a href="#" class="post-comments"><span class="commenter-name">
                        ${posts[i].username}</span></a>
                        <p>${posts[i].comment}</p>
                    </div> 
                    <a href="#" class="view-comments">View all comments</a>
                    <p class="post-time">1 HOUR AGO</p>
                </div> 
                
        </section>
      `
    }     
    
}

renderPosts()


